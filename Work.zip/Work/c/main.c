#include <stdio.h>

int main() {
    printf("Hello, C!\n"); // Выводит строку Hello, C!
    return 0; // Успешное завершение программы
}
